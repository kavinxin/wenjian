def dayin():
    print("wI m is!");

if __name__=="__main__":
    print("wellcome to china!");

__all__=['ren','student'];

